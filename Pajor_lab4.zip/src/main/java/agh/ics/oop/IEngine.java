package agh.ics.oop;

public interface IEngine {
    void run();
}
